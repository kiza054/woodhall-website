console.log(`Font Awesome Pro 6.0.0-beta1 by @fontawesome - https://fontawesome.com
License - https://fontawesome.com/license (Commercial License)
`)